import "./App.css";
import ChatApp from "./ChatApp";

function App() {
  return (
    <>
      <ChatApp />
    </>
  );
}

export default App;
